# exec(open('script.py').read())
print('Hello World!')