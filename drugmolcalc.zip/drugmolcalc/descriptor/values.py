from rdkit import Chem
from rdkit.Chem import Draw
from rdkit.Chem import Descriptors

def get_properties_and_analysis(smile):

    values={}
    mol = Chem.MolFromSmiles(smile)

    Draw.MolToFile(mol, 'static/images/mol.png')

    k=Descriptors.MolWt(mol)
    values['Molecular Weight']=k
    g=Descriptors.HeavyAtomMolWt(mol)
    values['Number of Heavy Atoms']=g
    b=Descriptors.FractionCSP3(mol)
    values['FractionCSP3']=b
    i=Descriptors.NumRotatableBonds(mol)
    values['Number of Rotatable Bonds']=i
    a=Descriptors.NumHAcceptors(mol)
    values['NumHAcceptors']=a
    l=Descriptors.NumHDonors(mol)
    values['NumHDonors']=l
    o=Descriptors.MolMR(mol)
    values['Molar Refractivity']=o
    C=Descriptors.TPSA(mol)
    values['TPSA']=C

    # Liphocity
    lipho={}
    x=Descriptors.MolLogP(mol)
    lipho['Log P']=x

    # Drug Likeness
    drug={}
    if(l<=5 and a<=10)and(k<=500 and x<=5):
        drug['Lipinski']='Yes; 0 violation'
    else:
        drug['Lipinski']='No;  violation'
    
    if(-0.4>=x<=5.6 and 40>=o<=130)and(160>=k<=480 and 70>=x<=20):
        drug['Ghose']='No'
    else:
        drug['Ghose']='Yes'
    
    if(i<=10)and(C<=140):
        drug['Veber']='Yes'
    else:
        drug['Veber']='No'

    if(x<=5.88)and(C<=131.6):
        drug['Egan']='Yes'
    else:
        drug['Egan']='No'
    
    m=Descriptors.NumAliphaticRings(mol)
    t=Descriptors.NumHeteroatoms(mol)

    if(200>=k<=600 and -2>=x<=5)and(C<=150 and m<=7) and(t>1 and i<=15) and(a<=10 and l<=10):
        drug['Muegge']='Yes'
    else:
        drug['Muegge']='No , Voilation Found'
    
    # Medicinal Chemistry
    medicinal_chem={}
    if(250>=k<=350 and x<=3.5 and i<=7):
        medicinal_chem['Leadlikeness'] = 'Yes'
    else:
        medicinal_chem['Leadlikeness'] = 'No,Voilation Found'

    result={'search_term':smile,'prop':values, 'lipho':lipho, 'drug':drug, 'med':medicinal_chem}
    
    return result