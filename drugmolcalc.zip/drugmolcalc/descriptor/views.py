from django.http import HttpResponse
from django.shortcuts import render
from . import values
# 'request' name is convention. It can be some other name too.
def index(request) :    
  return HttpResponse("Hello World")

def thank(req):
  val = values.get_properties_and_analysis('N(=O)[O]')
  return render(req, 'index.html',context=val)